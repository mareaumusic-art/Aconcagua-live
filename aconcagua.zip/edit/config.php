<?php

define('SITE_DIR', '../');
define('SITE_OWNER_ID', 479657);
define('ALLOWED_ORIGINS', 'https://c.ybnz.com, http://c.ybnz.com');
define('UPLOAD_MAX_FILESIZE', '10M');
define('ALLOWED_FILE_TYPES', 'js, json, mobirise, doc, pdf, xls, eot, ppt, odp, odt, pptx, xlsx, docx, xml, otf, ttf, woff, woff2, gif, jpeg, jpg, png, webp, svg, ico, css, html, less, map, txt');
define('JWT_PUBLIC_KEY', '-----BEGIN PUBLIC KEY-----
MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEApqyE1uM+Uj8FFt286Tgq
j3tdv9g0EyxN8AYmgZrcSRecMJzHaXZra7Q7mbozwU8jm9iLOxqMmrnEV7phtBuf
11/lKS0eoqU6aEdU5fQuHEijuYuJlzHE/6CHCQEEY1OPsr/Qd8T8mAkSyBOd660l
UzGtB7ncJDLDDzJRW5N9qBdQKDh+3mG/LKVIg6bR6uofPmO9JMifvGHzYOAnQzQm
c8UEXmlrcKQVkMIr2uAi9d461SnHV58/7tJSFOnZsrTCI/s7RXiUzlRuyzxmdHoW
TBQxZ40HXsI39iaHvvnLNXaYgjou8y17rNoxOSLrO42+KIfFJw5KJjAF2miVUjKy
8zJ7zqhn6nxXKyd/Ef+2T7lQIvfgbfgyCSCogCO8lawfoKAeGtuVu9FrXyC0YTfP
mKOJbqQQfz7BEPOXWjJdoILroYKyxA5RBo3LBdPiXu9JfeLcpyKAoaWSG7tQaRVN
tAO/EVZ2Huw01f+vTgkxpi3zu5T7RicnX9vfMu7QOJALWGDRximNn99VUucorLEZ
04awGjMNLD0w0bGmoMYPawyLYIC+jP+Z1NsDfrGeacVkoAwmkZ0rFQB5DaCk3Goz
9tbC3zi4mYvngqLhfPT7AKhBWFDWKsWrIQAelLaWA26oxkT2rBhmApDA2VOooeP7
X8YbQxTnSWfG/oSAh5mG5BkCAwEAAQ==
-----END PUBLIC KEY----- ');